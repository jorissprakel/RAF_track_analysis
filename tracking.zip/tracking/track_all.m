function track_all(bp_high, bp_low, featsize, filtsize, thresh)

%a=dir(['bg_removed/*.tif']);
a=dir(['*.tif']);
numframes = size(a,1)-1;
x=[];
y=[];
t=[];
bright=[];
Rg=[];

for j=1:numframes  
fprintf('Running frame...%d \n',j);

counter=num2str((j),'%04d');
%filename=['bg_removed/im_' num2str(counter) '.tif'];
filename=['im_' num2str(counter) '.tif'];


frame=double(imread(filename));

%inversion for brightfield
frame=imcomplement(frame);


frame_bp = bpass(frame,bp_low,bp_high);
frame_bp=250*frame_bp/max(max(frame_bp)); %stretch frame contrast back to 8bit
pk = pkfnd(frame_bp,thresh,featsize);
cnt = cntrd(frame_bp,pk,filtsize);
emp=isempty(cnt);

      if emp == 0
        thist = zeros(length(cnt),1);
        thist=thist+j;
        if length(cnt(:,1))==length(thist)
        x=[x;cnt(:,1)];
        y=[y; cnt(:,2)];
        t=[t; thist];
        bright = [bright; cnt(:,3)];
        Rg=[Rg; cnt(:,4)];
        end
      end

end
positionlist=[];
if length(x)>0
positionlist(:,1)=x;
positionlist(:,2)=y;
positionlist(:,3)=t;
positionlist(:,4)=bright;
positionlist(:,5)=Rg;
end
save('positions.mat', 'positionlist'); 


