function create_traject(positionlist,pixtomicrons);

%input
mem = 1; %number of acceptable steps a particle is 'lost' to interpolate trajectory
dim = 2; %dimensionality of position data
good = 20; %minimum length of trajectory to be stored (eliminates short traces)
maxdisp = 5; %maximum displacement between adjacent frames]

param.mem = 0;
param.dim=dim;
param.good=good;
param.quiet=0; %allow or switch of text output (0: output, 1: silent)

positionlist=positionlist(:,1:3);

[tracks] = track(positionlist,maxdisp,param);
tracks(:,1)=tracks(:,1)*pixtomicrons;
tracks(:,2)=tracks(:,2)*pixtomicrons;


numberoftracks = max(tracks(:,4))

save('tracks.mat', 'tracks'); 
tr=tracks;
save('tr.mat','tr');