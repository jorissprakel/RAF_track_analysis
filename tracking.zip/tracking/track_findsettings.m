function track_findsettings

frame=1;
bp_low = 1; %lower bp cutoff
bp_high = 15; %upper bp cutoff
thresh = 50; %threshold value for peak intensity
featsize = 4; %feature size in pixels
filtsize = 7; %size for centroid filter (larger than featsize, not so large it captures neighbors)

%first plot the original data
set(0,'DefaultFigureVisible','On');

counter=num2str((frame),'%04d');
%filename=['bg_removed/im_' num2str(counter) '.tif'];
filename=['im_' num2str(counter) '.tif'];
thisframe=double(imread(filename));

%inversion for brightfield data
%thisframe=imcomplement(thisframe);


%rawname=['raw/im_' counter '.tif'];
%rawframe=double(imread(rawname));
figure;
%subplot(1,2,1);
%colormap('gray'), imagesc(rawframe);

%perform a spatial bandpass filtering
frame_bp = bpass(thisframe,bp_low,bp_high);
frame_bp=250*frame_bp/max(max(frame_bp));
figure;
hold all;
colormap('gray'), imagesc(thisframe);

%peak finding algorithm is called
pk = pkfnd(frame_bp,thresh,featsize);
cnt = cntrd(frame_bp,pk,filtsize);
hold all
plot(cnt(:,1),cnt(:,2),'r+','LineWidth',2);
axis equal;


prompt = 'Satisfied with tracking settings (1 = yes, 0 = no)? ';
satif = input(prompt);

if satif == 1
    save('trackparam.mat','bp_low','bp_high', 'thresh', 'featsize', 'filtsize');
end




